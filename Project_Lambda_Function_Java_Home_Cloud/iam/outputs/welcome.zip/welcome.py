def hello (event, context) :
    print ("welcome to terraform ; please carry on hardwork")
